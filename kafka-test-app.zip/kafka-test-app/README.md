# Kafka Test Application

This application is designed to diagnose Kafka connectivity issues in an AWS Kubernetes environment with App Mesh.

## Features

- Connect to external Kafka brokers
- Test producer and consumer functionality
- Web UI for testing and configuration
- Dynamic configuration management (reload configuration without restart)
- Diagnostic tools for Kafka connectivity

## Configuration

The application uses the following configuration properties (in `application.properties`):

```properties
# Server settings
server.port=8080

# Kafka settings
kafka.bootstrap-servers=broker1:9092
kafka.client-id=kafka-test-app
kafka.consumer-group-id=kafka-test-group
kafka.concurrency=3
kafka.listener.topic=test-topic
```

## Running the Application

You can run the application using Maven:

```bash
mvn spring-boot:run
```

Or package it and run the JAR:

```bash
mvn package
java -jar target/kafka-test-app-0.0.1-SNAPSHOT.jar
```

## Deploying to Kubernetes

To deploy this application to Kubernetes, use the provided deployment YAML files:

```bash
kubectl apply -f kubernetes/deployment.yaml
kubectl apply -f kubernetes/service.yaml
kubectl apply -f kubernetes/appmesh-config.yaml
```

## Using the Web UI

Once the application is running, access the Web UI at `http://localhost:8080`

The UI provides:
- Producer tab for sending messages
- Consumer tab for viewing received messages
- Configuration tab for updating Kafka settings
- Diagnostics tab for testing connectivity and viewing broker information

## Handling Kafka Brokers in App Mesh/Envoy Environment

This application is specifically designed to work with App Mesh and Envoy in AWS Kubernetes. It handles the challenge of multiple brokers using the same port (9092) by implementing a Kafka Bridge approach.

## Troubleshooting

If you encounter issues:

1. Use the Diagnostics tab to test connectivity
2. Check Kubernetes logs: `kubectl logs -n kafka-test deployment/kafka-test-app`
3. Verify App Mesh configuration is properly routing traffic to the Kafka brokers