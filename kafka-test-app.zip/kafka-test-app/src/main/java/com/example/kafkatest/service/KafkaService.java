package com.example.kafkatest.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

@Service
public class KafkaService {

    private static final Logger logger = LoggerFactory.getLogger(KafkaService.class);
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final List<String> receivedMessages = new ArrayList<>();
    private CountDownLatch latch = new CountDownLatch(1);

    public KafkaService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(String topic, String key, String message) {
        logger.info("Sending message to topic: {}, key: {}, message: {}", topic, key, message);
        
        kafkaTemplate.send(topic, key, message)
            .addCallback(
                result -> logger.info("Message sent successfully to topic: {}, partition: {}, offset: {}", 
                    topic, 
                    result != null ? result.getRecordMetadata().partition() : "unknown", 
                    result != null ? result.getRecordMetadata().offset() : "unknown"),
                ex -> logger.error("Failed to send message to topic: {}, error: {}", topic, ex.getMessage())
            );
    }

    @KafkaListener(topics = "${kafka.listener.topic:test-topic}", groupId = "${kafka.consumer-group-id}")
    public void listen(@Payload String message, 
                      @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
                      @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
                      @Header(KafkaHeaders.OFFSET) long offset,
                      Acknowledgment acknowledgment) {
        
        logger.info("Received message: {} from topic: {}, partition: {}, offset: {}", message, topic, partition, offset);
        receivedMessages.add(message);
        acknowledgment.acknowledge();
        latch.countDown();
    }

    public boolean waitForMessage(long timeout, TimeUnit unit) throws InterruptedException {
        return latch.await(timeout, unit);
    }

    public void resetLatch(int count) {
        this.latch = new CountDownLatch(count);
    }

    public List<String> getReceivedMessages() {
        return new ArrayList<>(receivedMessages);
    }

    public void clearReceivedMessages() {
        receivedMessages.clear();
    }
}