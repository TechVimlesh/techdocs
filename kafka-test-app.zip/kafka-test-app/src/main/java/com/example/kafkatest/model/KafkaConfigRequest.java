package com.example.kafkatest.model;

import java.util.Map;

public class KafkaConfigRequest {
    private String bootstrapServers;
    private String clientId;
    private String consumerGroupId;
    private int concurrency;
    private Map<String, Object> additionalProducerProps;
    private Map<String, Object> additionalConsumerProps;

    public String getBootstrapServers() {
        return bootstrapServers;
    }

    public void setBootstrapServers(String bootstrapServers) {
        this.bootstrapServers = bootstrapServers;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getConsumerGroupId() {
        return consumerGroupId;
    }

    public void setConsumerGroupId(String consumerGroupId) {
        this.consumerGroupId = consumerGroupId;
    }

    public int getConcurrency() {
        return concurrency;
    }

    public void setConcurrency(int concurrency) {
        this.concurrency = concurrency;
    }

    public Map<String, Object> getAdditionalProducerProps() {
        return additionalProducerProps;
    }

    public void setAdditionalProducerProps(Map<String, Object> additionalProducerProps) {
        this.additionalProducerProps = additionalProducerProps;
    }

    public Map<String, Object> getAdditionalConsumerProps() {
        return additionalConsumerProps;
    }

    public void setAdditionalConsumerProps(Map<String, Object> additionalConsumerProps) {
        this.additionalConsumerProps = additionalConsumerProps;
    }
}