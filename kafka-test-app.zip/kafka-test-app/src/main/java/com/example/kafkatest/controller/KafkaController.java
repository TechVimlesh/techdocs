package com.example.kafkatest.controller;

import com.example.kafkatest.config.KafkaConfigProperties;
import com.example.kafkatest.model.KafkaConfigRequest;
import com.example.kafkatest.model.KafkaMessageRequest;
import com.example.kafkatest.service.KafkaService;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.context.refresh.ContextRefresher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/kafka")
@RefreshScope
public class KafkaController {

    private final KafkaService kafkaService;
    private final KafkaConfigProperties kafkaConfigProperties;
    private final ContextRefresher contextRefresher;
    private final AdminClient adminClient;

    @Autowired
    public KafkaController(KafkaService kafkaService, 
                          KafkaConfigProperties kafkaConfigProperties,
                          ContextRefresher contextRefresher,
                          AdminClient adminClient) {
        this.kafkaService = kafkaService;
        this.kafkaConfigProperties = kafkaConfigProperties;
        this.contextRefresher = contextRefresher;
        this.adminClient = adminClient;
    }

    @PostMapping("/send")
    public ResponseEntity<String> sendMessage(@RequestBody KafkaMessageRequest request) {
        kafkaService.sendMessage(request.getTopic(), request.getKey(), request.getMessage());
        return ResponseEntity.ok("Message sent to topic: " + request.getTopic());
    }

    @GetMapping("/config")
    public ResponseEntity<Map<String, Object>> getConfig() {
        Map<String, Object> config = new HashMap<>();
        config.put("bootstrapServers", kafkaConfigProperties.getBootstrapServers());
        config.put("clientId", kafkaConfigProperties.getClientId());
        config.put("consumerGroupId", kafkaConfigProperties.getConsumerGroupId());
        config.put("concurrency", kafkaConfigProperties.getConcurrency());
        config.put("additionalProducerProps", kafkaConfigProperties.getAdditionalProducerProps());
        config.put("additionalConsumerProps", kafkaConfigProperties.getAdditionalConsumerProps());
        return ResponseEntity.ok(config);
    }

    @PostMapping("/config")
    public ResponseEntity<String> updateConfig(@RequestBody KafkaConfigRequest request) {
        kafkaConfigProperties.setBootstrapServers(request.getBootstrapServers());
        kafkaConfigProperties.setClientId(request.getClientId());
        kafkaConfigProperties.setConsumerGroupId(request.getConsumerGroupId());
        kafkaConfigProperties.setConcurrency(request.getConcurrency());
        
        if (request.getAdditionalProducerProps() != null) {
            kafkaConfigProperties.setAdditionalProducerProps(request.getAdditionalProducerProps());
        }
        
        if (request.getAdditionalConsumerProps() != null) {
            kafkaConfigProperties.setAdditionalConsumerProps(request.getAdditionalConsumerProps());
        }
        
        return ResponseEntity.ok("Configuration updated");
    }

    @PostMapping("/refresh")
    public ResponseEntity<String> refresh() {
        contextRefresher.refresh();
        return ResponseEntity.ok("Kafka configuration refreshed");
    }
    
    @GetMapping("/topics")
    public ResponseEntity<Set<String>> listTopics() throws ExecutionException, InterruptedException {
        ListTopicsResult topics = adminClient.listTopics();
        return ResponseEntity.ok(topics.names().get());
    }
    
    @GetMapping("/test-connection")
    public ResponseEntity<String> testConnection() {
        try {
            Set<String> topics = adminClient.listTopics().names().get();
            return ResponseEntity.ok("Successfully connected to Kafka. Available topics: " + topics);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to connect to Kafka: " + e.getMessage());
        }
    }
}