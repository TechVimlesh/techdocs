package com.example.kafkatest.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "kafka")
@RefreshScope
public class KafkaConfigProperties {
    private String bootstrapServers = "broker1:9092";
    private String clientId = "kafka-test-app";
    private String consumerGroupId = "kafka-test-group";
    private int concurrency = 3;
    private Map<String, Object> additionalProducerProps = new HashMap<>();
    private Map<String, Object> additionalConsumerProps = new HashMap<>();

    public String getBootstrapServers() {
        return bootstrapServers;
    }

    public void setBootstrapServers(String bootstrapServers) {
        this.bootstrapServers = bootstrapServers;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getConsumerGroupId() {
        return consumerGroupId;
    }

    public void setConsumerGroupId(String consumerGroupId) {
        this.consumerGroupId = consumerGroupId;
    }

    public int getConcurrency() {
        return concurrency;
    }

    public void setConcurrency(int concurrency) {
        this.concurrency = concurrency;
    }

    public Map<String, Object> getAdditionalProducerProps() {
        return additionalProducerProps;
    }

    public void setAdditionalProducerProps(Map<String, Object> additionalProducerProps) {
        this.additionalProducerProps = additionalProducerProps;
    }

    public Map<String, Object> getAdditionalConsumerProps() {
        return additionalConsumerProps;
    }

    public void setAdditionalConsumerProps(Map<String, Object> additionalConsumerProps) {
        this.additionalConsumerProps = additionalConsumerProps;
    }
}