# Kafka Test Application

This repository contains a test application designed to diagnose Kafka connectivity issues in an AWS Kubernetes environment with App Mesh.

## Setting Up the Test Environment in AWS Kubernetes

### 1. Create a Kubernetes Namespace
Run the following command to create a dedicated namespace for the test application:
```sh
kubectl create namespace kafka-test
```

### 2. Deploy the Test Application
Create a `Deployment` YAML file (`kafka-test-deployment.yaml`) with the following content:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: kafka-test-app
  namespace: kafka-test
spec:
  replicas: 1
  selector:
    matchLabels:
      app: kafka-test-app
  template:
    metadata:
      labels:
        app: kafka-test-app
    spec:
      containers:
      - name: kafka-test-app
        image: [your-container-registry]/kafka-test-app:latest
        ports:
        - containerPort: 8080
```

Apply the deployment using:
```sh
kubectl apply -f kafka-test-deployment.yaml
```

### 3. Configure App Mesh
To enable proper routing, create a `VirtualService` (`kafka-virtual-service.yaml`):

```yaml
apiVersion: appmesh.k8s.aws/v1beta2
kind: VirtualService
metadata:
  name: kafka-broker-vs
  namespace: kafka-test
spec:
  awsName: kafka-broker-vs.kafka-test.svc.cluster.local
  provider:
    virtualRouter:
      virtualRouterRef:
        name: kafka-router
```

Apply the virtual service:
```sh
kubectl apply -f kafka-virtual-service.yaml
```

Then, define a `VirtualRouter` (`kafka-virtual-router.yaml`):

```yaml
apiVersion: appmesh.k8s.aws/v1beta2
kind: VirtualRouter
metadata:
  name: kafka-router
  namespace: kafka-test
spec:
  listeners:
  - portMapping:
      port: 9092
      protocol: tcp
  routes:
  - name: kafka-route
    tcpRoute:
      action:
        weightedTargets:
        - virtualNodeRef:
            name: kafka-broker-vn
          weight: 1
```

Apply the virtual router:
```sh
kubectl apply -f kafka-virtual-router.yaml
```

### 4. Create a Kubernetes Service
Create a service (`kafka-test-service.yaml`) to expose the test application:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: kafka-test-app
  namespace: kafka-test
spec:
  selector:
    app: kafka-test-app
  ports:
  - port: 8080
    targetPort: 8080
  type: ClusterIP
```

Apply the service:
```sh
kubectl apply -f kafka-test-service.yaml
```

## Conclusion
After deploying the test application and setting up App Mesh routing, you can analyze the connectivity between your application and Kafka to troubleshoot potential networking issues.

